package tasf.mx.ctrlventas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class index {

	public static void main(String[] args) {
		SpringApplication.run(index.class, args);
	}

}
